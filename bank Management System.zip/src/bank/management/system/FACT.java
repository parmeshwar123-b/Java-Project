public class FACT {
    public static void main(String[] args) {
        int a , b=1;
        int number=5 ;
        for(a=1; a<=number;a++ ){
          b=a*b;
        }
        System.out.println(b);  
    }
}
